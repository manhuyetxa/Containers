<?php get_header(); ?>	

	You can set an LC powered page to serve as 404 page in WP admin > Live Composer > Archives and Search.

<?php get_footer(); ?>