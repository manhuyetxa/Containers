<?php
	
	if ( ! defined( 'DS_LIVE_COMPOSER_VER' ) ) {

		function lct_requirement_notification_scripts() {

			wp_enqueue_style( 'lct-importer-style', get_template_directory_uri() . '/inc/importer/css/main.css', array(), '1.0' );

		} add_action( 'admin_enqueue_scripts', 'lct_requirement_notification_scripts' );

		function lct_requirement_notification() {

			?>

			<div class="lct-requirement-notification">
				
				<div class="lct-requirement-notification-inner">

					<p><a target="_blank" href="https://wordpress.org/plugins/live-composer-page-builder/">Live Composer</a> plugin is <strong>required</strong> and has to be active for this theme to function. </p>


				</div><!-- .lct-importer-inner -->

			</div>

			<?php

		} add_action( 'admin_notices', 'lct_requirement_notification' );

	} elseif ( defined( 'DS_LIVE_COMPOSER_VER' ) && get_option( 'lct_orao_ajax_installer', 'open' ) != 'closed' ) {

		include get_template_directory() . '/inc/importer/ajax.php';

		function lct_importer_scripts() {

			wp_enqueue_style( 'lct-importer-style', get_template_directory_uri() . '/inc/importer/css/main.css', array(), '1.0' );
			wp_enqueue_script( 'lct-importer-js', get_template_directory_uri() . '/inc/importer/js/main.js', array(), '1.0' );			
			wp_localize_script( 'lct-importer-js', 'LCTImporterAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );


		} add_action( 'admin_enqueue_scripts', 'lct_importer_scripts' );

		function lct_importer_notification() {

			?>

			

			<?php

		} add_action( 'admin_notices', 'lct_importer_notification' );

	}
